import json

class YardSearcher:
    def __init__(self, json_file_path=None):
        """
        Initialize YardSearcher by reading data from a JSON file.
        
        Args:
            json_file_path (str): Path to the JSON file containing yard, init, and goal data. Can be None.
        """

        if json_file_path:
            with open(json_file_path, 'r') as file:
                data = json.load(file)
            
            self.yard = data['yard']
            self.init = data['init']
            self.goal = data['goal']
    
    def __str__(self):
        """String representation of the YardSearcherAI object."""
        return f"YardSearcherAI:\nYard: {self.yard}\nInit: {self.init}\nGoal: {self.goal}"

    # PROBLEM 1
    def possible_actions(self, state):
        """
        Provides a list of all possible actions given a state (see project documentation).

        A State is a List[List[str]]
        An Action is a tuple[str, int, int]
        
        Args:
            state (State):  A given state.

        Returns:
            List[State] : A list of all possible actions that can be done on that state.

        """

        actions = []

        # BEGIN SOLUTION

        # YOUR CODE HERE

        # END SOLUTION

        return actions

    # PROBLEM 2
    def result(self, action, state):
        """
        Consumes an action and a state and produces the state 
            that results from applying that action on the given state.

        Args:
            action (Action): The given action.
            state (State): The given state.

        Returns:
            State : The resulting state after applying "action" to "state".

        """
        resulting_state = None

        # BEGIN SOLUTION
        
        # YOUR CODE HERE

        # END SOLUTION

        return resulting_state

    # PROBLEM 3
    def apply_action_sequence(self, action_sequence, state):
        """
        Consumes an action sequence and a state, and produces the state
            that results from applying the actions on a state.

        Args:
            action_sequence (List[Action]) : A list of actions.
            state (State) : The given state

        Returns:
            State : The resulting state after applying the actions in `action_sequence` 
                        on `state` in order.
        """
        resulting_state = None

        # BEGIN SOLUTION
        
        # YOUR CODE HERE

        # END SOLUTION

        return resulting_state

    # PROBLEM 4
    def uninformed_search(self, init_state, goal_state):
        """
        Using an UNINFORMED search algorithm, returns an OPTIMAL sequence of 
            actions that transforms an intial state into a goal state.
            There may be multiple shortest paths, but you only need to find one.

        Args:
            init_state (State) : The initial state.
            goal_state (State) : The goal state.

        Returns:
            List[Action] : A sequence of actions that transforms the initial state into the
                goal state. The action sequence is an optimal path (e.g. a shortest path). 
                There may be multiple shortest paths, but you only need to find one.

            int : The total number of nodes explored during run of the search algorithm.

        """
        
        path = []
        nodes_explored = 0

        # BEGIN SOLUTION
        
        # YOUR CODE HERE

        # END SOLUTION

        return path, nodes_explored
    
    # PROBLEM 5
    def heuristic_function(self, init_state, goal_state):
        """
        An ADMISSIBLE heuristic that returns an estimated cost between
            an intial state and a goal state.

        Args:
            init_state (State) : The initial state.
            goal_state (State) : The goal state.

        Returns:
            float : The estimated path cost between `init_state` and `goal_state`.
                This cost will never overestimate the distance from the intitial
                and goal state.

        """

        heuristic_score = 0

        # BEGIN SOLUTION
        
        # YOUR CODE HERE

        # END SOLUTION


        return heuristic_score

    # PROBLEM 6
    def astar_search(self, init_state, goal_state):
        """
        Using the A* search algorithm, returns an OPTIMAL sequence of 
            actions that transforms an intial state into a goal state.
            There may be multiple shortest paths, but you only need to find one.

        Args:
            init_state (State) : The initial state.
            goal_state (State) : The goal state.

        Returns:
            List[Action] : A sequence of actions that transforms the initial state into the
                goal state. The action sequence is an optimal path (e.g. a shortest path). 
                There may be multiple shortest paths, but you only need to find one.

            int : The total number of nodes explored during run of the search algorithm.

        """

        path = []
        nodes_explored = 0

        # BEGIN SOLUTION
        
        # YOUR CODE HERE

        # END SOLUTION

        return path, nodes_explored

def main():
    # Feel free to edit code in the main function for your own testing purposes...
    searcher = YardSearcher("./yards/yard_1_EASY.json")

    path, nodes_explored = searcher.uninformed_search(searcher.init, searcher.goal)
    print("Path to goal: ", path)
    print("Length of path: ", len(path))
    print("Total number of nodes explored: ", nodes_explored)

if __name__ == "__main__":
    main()
