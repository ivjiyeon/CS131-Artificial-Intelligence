class FOLAtom:
    def __init__(self, predicate, *args):
        self.atom = [predicate]+list(args) 

    def __repr__(self):
        return str(self.atom)
    
    def __str__(self):
        return str(self.atom)
    
    # Unify two FOLAtoms x and y with existing bindings
    def unify(x, y, bindings = {}):
        new_bindings = None

        # 2.1: Unify
        # BEGIN SOLUTION

        # END SOLUTION

        return new_bindings
    
    # Chase a binding through a bindings list
    def get_terminal_binding(var, intermediate_bindings):
        var = None

        # 2.2: Get Terminal Bindings
        # BEGIN SOLUTION

        # END SOLUTION

        return var

class FOLClause:
    def __init__(self, *atoms):
        self.atoms = list(atoms)

    def is_empty(self):
        return len(self.atoms) == 0


    def __str__(self):
        return "FOLClause: "+str(self.atoms)

    def __repr__(self):
        return "FOLClause: "+str(self.atoms)
    
    # Get the final bindings of a clause given a full binding list
    def get_final_bindings(self, intermediate_bindings):
        final_bindings = {}

        # 2.2: Chasing Bindings
        # BEGIN SOLUTION

        # END SOLUTION

        return final_bindings
    
    # Uniquify a clause with fresh variable names
    def uniquify(clause):
        unique_clause = []

        # 2.2: Uniquify
        # BEGIN SOLUTION

        # END SOLUTION

        return unique_clause

    # Resolve a support clause against a kb_clause with existing bindings
    def support_resolve(support_clause, kb_clause, bindings={}):
        new_clause = None

        # 2.4: FOL Support Resolve
        # BEGIN SOLUTION

        # END SOLUTION

        return new_clause
    

class ResolveNodeFOL:

    def __init__(self, support, bindings = {}):
        self.support = support
        self.bindings = bindings

    def __str__(self):
        return str(self.support)+" : "+str(self.bindings)
    
    def __repr__(self):
        return "Resolution FOL Node: "+str(self.support)+" : "+str(self.bindings)

    # Generate successors of a FOL node using the resolve function
    def generate_successors(self,kb):
        successors = [] 

        # 2.4: Generate FOL Successors
        # BEGIN SOLUTION

        # END SOLUTION
                

        return successors