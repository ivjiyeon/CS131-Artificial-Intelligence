class PropClause:
    def __init__(self, *literals):
        self.literals = list(literals)

    def is_empty(self):
        return len(self.literals) == 0

    def __str__(self):
        return "PropClause: "+str(self.literals)

    def __repr__(self):
        return "PropClause: "+str(self.literals)

    # Resolve a support clause against a kb_clause
    def support_resolve(support_clause, kb_clause):
        new_clause = None

        # 1.1: Propositional Support Resolve
        # BEGIN SOLUTION

        # END SOLUTION

        return new_clause
        
class ResolveNodeProp:
    def __init__(self, support):
        self.support = support

    def __str__(self):
        return str(self.support)
    
    def __repr__(self):
        return "Resolution Prop Node: "+str(self.support)

    # Generate successors of a FOL node using the resolve function
    def generate_successors(self,kb):
        successors = []

        # 1.2: Generate Propositional Successors
        # BEGIN SOLUTION

        # END SOLUTION

        return successors