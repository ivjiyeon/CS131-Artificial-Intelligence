Run using:
`python ResolutionProver.py`

Run tests using:
`python test.py -q {q1..q8}`